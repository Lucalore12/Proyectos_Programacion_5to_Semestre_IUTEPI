const { Client, GatewayIntentBits,Collection, Partials , EmbedBuilder } = require('discord.js');
const fs = require('fs');
const connectDB = require('./db');
const cron = require('node-cron');
connectDB();
const Reminder = require('./models/Reminder');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent ,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages ,
        GatewayIntentBits.GuildMembers ,
    ],
    partials: [
      Partials.Channel,
      Partials.Message
    ]
});
const prefix = '&';
client.commands = new Collection();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    client.commands.set(command.name, command);
}
client.once('ready', () => {
    console.log('¡Estoy listo! Soy Reminder');
    cron.schedule('* * * * *', async () => {
        const now = new Date();
        const reminders = await Reminder.find({ remindAt: { $lte: now } });
        reminders.forEach(async reminder => {
            const user = await client.users.fetch(reminder.userId);
            const embedRecordatorio = new EmbedBuilder()
            .setTitle('Reminder')
            .setDescription('Recordatorio')
            .setColor('#0099ff')
            .addFields(
            { name: 'Contenido:', value: `${reminder.message}`, inline: false },
        )
            user.send({ embeds: [embedRecordatorio] });
            await Reminder.findByIdAndDelete(reminder._id);
        });
    });
});
client.on('messageCreate', async message => {
    if (message.author.bot) return;
    const timestamp = new Date().toISOString();
    if (message.channel.name === undefined){
        console.log(`DM recibido de ${message.author.username} a las ${timestamp}: ${message.content}`);
    }
    else {

        console.log(`Mensaje recibido de ${message.author.username} en el canal ${message.channel.name} a las ${timestamp}: ${message.content}`);
    }
    if (message.attachments.size > 0) {
        message.attachments.forEach(attachment => {
            
            if (attachment.contentType.startsWith('image/')) {
                console.log(`El mensaje contiene una imagen: ${attachment.url}`);
            }
        });
    }
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    if (!client.commands.has(commandName)) return;
    const command = client.commands.get(commandName);
    try {
        command.execute(message, args);
    } catch (error) {
        console.error(error);
        message.reply('Hubo un error al intentar ejecutar ese comando.');
    }
});
//TOken del Bot
client.login('MTMwNDg4MjAzMjk2MjE3NTEwOQ.Gt0BVr.Tqz4mrVBQKvLt7n6UVcsuxHMQ54ewkf-7hwYAA');

