const {EmbedBuilder } = require('discord.js');


module.exports = {
    name: 'embed',
    description: 'Crea un recordatorio',
    async execute(message, args) {
        const embed = new EmbedBuilder()
            .setTitle('Mi Mensaje Embed')
            .setDescription('Esta es la descripción del embed')
            .setColor('#0099ff')
            .addFields(
                { name: 'Campo 1', value: 'Este es el primer campo', inline: false },
                { name: 'Campo 2', value: 'Este es el segundo campo', inline: false },
                { name: 'Campo 3', value: 'Este es el tercer campo', inline: false }
            )
            
        // Enviar el embed
        try {
            await message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Error al enviar el embed:', error);
            message.channel.send('Hubo un error al enviar el mensaje embed.');
        }
    }
}