const {EmbedBuilder } = require('discord.js');
const Reminder = require('../models/Reminder');

module.exports = {
    name: 'remind',
    description: 'Crea un recordatorio',
    async execute(message, args) {
        const timeValue = parseInt(args.shift());
        const timeUnit = args.shift();
        const reminderMessage = args.join(' ');
        
        
        let remindAt = new Date();
        if (timeUnit === 'second') {
            remindAt.setSeconds(remindAt.getSeconds() + timeValue);
        } else if (timeUnit === 'minute') {
            remindAt.setMinutes(remindAt.getMinutes() + timeValue);
        } else if (timeUnit === 'hour') {
            remindAt.setHours(remindAt.getHours() + timeValue);
        } else if (timeUnit === 'day') {
            remindAt.setDate(remindAt.getDate() + timeValue);
        } else {
            const embedError = new EmbedBuilder()
            .setTitle('Reminder')
            .setDescription('Error')
            .setColor('#ff0000')
            .addFields(
            { name: 'Error:', value: 'Formato incorrecto.', inline: false },
            { name: 'Sintaxis:', value: 'Usa: &remind <cantidad> <unidad (minute/hour/day)> <mensaje>', inline: false },
            
            
        )
            message.channel.send({ embeds: [embedError] });
            return;
        }

        const reminder = new Reminder({
            userId: message.author.id,
            message: reminderMessage,
            remindAt: remindAt
        });

        await reminder.save();
        const embedCorrecto = new EmbedBuilder()
            .setTitle('Reminder')
            .setDescription('Esto te Lo Recordare')
            .setColor('#0099ff')
            .addFields(
                { name: 'Contenido:', value: `"${reminderMessage}"`, inline: false },
                { name: 'Tiempo', value: `${timeValue} ${timeUnit}`, inline: false },
                
            )
        message.channel.send({ embeds: [embedCorrecto] });
    }
};
